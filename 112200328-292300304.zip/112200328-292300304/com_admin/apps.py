from django.apps import AppConfig


class ComAdminConfig(AppConfig):
    name = 'com_admin'
