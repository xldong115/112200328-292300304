from django.http import JsonResponse
from django.shortcuts import render, redirect
from com import models
from utils.md5 import md5

def user_register(request):
    if request.method == 'GET':
        return render(request, 'user/register.html')
    form_error = '账号错误或密码错误'
    username = request.POST.get('username')
    password = request.POST.get('password')
    data = {
        'username': username,
        'password': md5(password),
    }
    print('data', data)
    if not username or not password:
        return render(request, 'user/register.html', locals())
    exist = models.UserInfo.objects.filter(username=username).exists()
    if exist:
        form_error = '用户名已存在'
        return render(request, 'user/register.html', locals())
    try:
        models.UserInfo.objects.create(**data)
        return redirect('user_login')
    except Exception:
        form_error = '创建失败,信息不合法'
        return render(request, 'user/register.html', locals())

def user_login(request):
    if request.method == 'GET':
        return render(request, 'user/login.html')
    form_error = '账号错误或密码错误'
    username = request.POST.get('username')
    password = request.POST.get('password')
    user_query = models.UserInfo.objects.filter(username=username, password=md5(password), is_active=True)
    if not user_query.exists():
        return render(request, 'user/login.html', {'form_error': form_error})
    user_obj = user_query.first()
    request.session['user_dic'] = {'id': user_obj.id, 'username': user_obj.username,
                                   'user_type': user_obj.user_type,
                                   'avatar': user_obj.avatar.url,
                                   'addr': user_obj.addr,
                                   'telephone': user_obj.telephone,
                                   }
    return redirect('home')

def login_out(request):
    user_id = request.session.get('user_dic')['id']
    user_obj = models.UserInfo.objects.get(id=user_id)
    user_obj.is_login = False
    user_obj.save()
    request.session.clear()
    return redirect('user_login')

def ajax_change_icon_view(request):
    user_id = request.session.get('user_dic')['id']
    user_obj = models.UserInfo.objects.get(id=user_id)
    new_img = request.FILES.get('icon')
    telephone = request.POST.get('telephone')
    addr = request.POST.get('addr')
    if new_img:
        user_obj.avatar = new_img
    if telephone:
        user_obj.telephone = telephone
    if addr:
        user_obj.addr = addr
    try:
        user_obj.save()
    except Exception:
        pass
    img_url = user_obj.avatar.url
    return JsonResponse({'status': 200, 'url': img_url})
