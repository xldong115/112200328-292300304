from django.apps import AppConfig


class ComAdminConfig(AppConfig):
    name = 'mysql_admin'
